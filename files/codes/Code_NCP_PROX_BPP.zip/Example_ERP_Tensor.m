% Author: Deqing Wang
% Email: deqing.wang@foxmail.com
% Website: http://deqing.me/
% Affiliation: Dalian University of Technology, China
%              University of Jyv�skyl�, Finland
% Date: October 17th, 2018.
%
% Require MATLAB Tensor Toolbox from
% http://www.sandia.gov/~tgkolda/TensorToolbox/
%
%%
clear;
close all

%% The data storage path
ERP_data_path = [pwd filesep 'ERP_MMN_Data'];
LoadData=load([ERP_data_path filesep 'Y_IJNS.mat']);
DataTensor=LoadData.Y;
load([ERP_data_path filesep 'chanlocs.mat']);
%%
% Tensor parameters
FrequencyMode           = 71;	% Representing 1-15Hz
TimeMode                = 60;	% Representing 0-300ms
ChannelMode             = 9;	% Representing 9 channels
SubjectConditionMode	= 42;   % Representing 21 in RD and AD groups.

%% Tensor Decomposition
TensorTrue = tensor(double(DataTensor));
N = ndims(TensorTrue);

% Tensor Decomposition Parameters
R = 40;
ProxParam=1e-4;
RegParams=repmat(ProxParam,N,1);

rng('shuffle');
[A,Out] = ncp_proximal(TensorTrue,R,'maxiters',99999,'tol',1e-8,...
    'init','random','regparams',RegParams,'printitn',1,...
    'maxtime',600,'stop',2);

%%
fprintf('\n');
fprintf('Total iteration is %d.\n',Out.iter);
fprintf('Elapsed time is %4.1f seconds.\n',Out.time(end));
fprintf('Objective function value is %.4e\n',Out.obj(end));
fprintf('Solution relative error = %4.4f\n\n',Out.relerr(2,end));

%%
% Nonzero column number
FactorNonzeroNum=zeros(ndims(tensor(TensorTrue)),1);
for i=1:ndims(tensor(TensorTrue))
    Factor_SparseIndex=(A.U{i}>1e-6);
    Factor_Sparse=A.U{i}.*double(Factor_SparseIndex);
    SumOfFactor=sum(Factor_Sparse,1);
    FactorNonzeroNum(i)=sum(SumOfFactor~=0);
end
% Reporting
fprintf('Nonzero Components Number:\n');
for i=1:ndims(tensor(TensorTrue))
    fprintf('Nonzero Components Number of A{%d}:\t%d\n',i,FactorNonzeroNum(i,1));
end
fprintf('\n');

%%
SpectralFactor=A.U{1};
TemporalFactor=A.U{2};
SpatialFactor=A.U{3};
SubjectConditionFactor=A.U{4};

%% Plot objective function value
figure;
semilogy(Out.time,Out.obj,'LineWidth',2);
grid on
sTitle=sprintf('%.0e',ProxParam);
title(['Objective Function Value (\alpha_n=' sTitle ')']);
xlabel('Time(s)');
ylabel('Objective Function Value');

